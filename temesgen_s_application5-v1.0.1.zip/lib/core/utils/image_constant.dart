class ImageConstant {
  static String imgTelevision = 'assets/images/img_television.svg';

  static String imgWomenpowerhome = 'assets/images/img_womenpowerhome.png';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgArrowleftBlueGray100 =
      'assets/images/img_arrowleft_blue_gray_100.svg';

  static String imgVectorGreen500 = 'assets/images/img_vector_green_500.svg';

  static String imgTicketGreen500 = 'assets/images/img_ticket_green_500.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
