class Frame1MenuModalModel {}
