import 'package:temesgen_s_application5/core/app_export.dart';
import 'package:temesgen_s_application5/presentation/frame_1_menu_modal_screen/models/frame_1_menu_modal_model.dart';

class Frame1MenuModalController extends GetxController {
  Rx<Frame1MenuModalModel> frame1MenuModalModelObj = Frame1MenuModalModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
