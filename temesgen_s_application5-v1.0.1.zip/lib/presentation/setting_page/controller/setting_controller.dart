import 'package:temesgen_s_application5/core/app_export.dart';
import 'package:temesgen_s_application5/presentation/setting_page/models/setting_model.dart';

class SettingController extends GetxController {
  SettingController(this.settingModelObj);

  Rx<SettingModel> settingModelObj;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
