import 'package:temesgen_s_application5/core/app_export.dart';

class ApiClient extends GetConnect {}
